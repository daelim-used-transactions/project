package com.daelim.transactions.controller;

import com.daelim.transactions.dto.BoardDTO;
import com.daelim.transactions.dto.BuyBoardDTO;
import com.daelim.transactions.service.BoardService;
import com.daelim.transactions.service.BuyBoardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class SaleBoardController {


    @Autowired
    BoardService saleBoardService;

    @GetMapping(value ="/main/view")
    public String openDetailBoard(@RequestParam(value="idx", required = false)Long idx,Model model){
        if(idx == null){
            return "redirect:/main";
        }
        BoardDTO saleBoard = saleBoardService.getBoardDetail(idx);
        if(saleBoard == null || "Y".equals(saleBoard.getDeleteYn())){
            return "redirect:/main";
        }
        model.addAttribute("board", saleBoard);
        return "/forSale";
    }
}