package com.daelim.transactions.mapper;

import com.daelim.transactions.dto.BoardDTO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface DaoSaleBoard {

    public int insertBoard(BoardDTO params);

    public BoardDTO selectBoard(int boardIdx);

    public int updateBoard(BoardDTO params);

    public int deleteBoard(int boardIdx);

    public List<BoardDTO> selectBoardList(int count);

    public int selectBoardTotalCount();

    public List<BoardDTO> selectBoardListById(String loginId);

    public int selectBoardMemberCount(String loginId);


    /**
     *  상세페이지 가져오기
     * */
    public BoardDTO selectBoardDetail(Long idx);
}
