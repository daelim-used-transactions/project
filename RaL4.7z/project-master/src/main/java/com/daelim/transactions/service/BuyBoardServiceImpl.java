package com.daelim.transactions.service;

import com.daelim.transactions.dto.BuyBoardDTO;
import com.daelim.transactions.mapper.DaoBuyBoard;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;

@Service @RequiredArgsConstructor
public class BuyBoardServiceImpl implements BuyBoardService {

    private final DaoBuyBoard daoBuyBoard;


    @Override
    public boolean registerBoard(BuyBoardDTO board) {
        return daoBuyBoard.insertBoard(board) == 1;  //DB에 들어갔다면 True
    }

    /**
     *  모든 게시판 찾기
     * */
    public List<BuyBoardDTO> getAttachList( ){
        List<BuyBoardDTO> boardList = Collections.emptyList();

        int boardTotalCount = daoBuyBoard.selectBoardTotalCount();

        if (boardTotalCount > 0) {
            boardList = daoBuyBoard.selectBoardList();
        }

        return boardList;
    }

    @Override
    public BuyBoardDTO getBoardDetail(long idx) {

        return daoBuyBoard.selectBoardDetail(idx);
    }

    ;


}

