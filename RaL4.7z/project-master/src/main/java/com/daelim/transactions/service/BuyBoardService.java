package com.daelim.transactions.service;

import com.daelim.transactions.dto.BuyBoardDTO;

import java.util.List;

public interface BuyBoardService {

    public boolean registerBoard(BuyBoardDTO board);

    /**
     *  모든 게시판 찾기
     * */
    public List<BuyBoardDTO> getAttachList( );

    public BuyBoardDTO getBoardDetail(long idx);
}
